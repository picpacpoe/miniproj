package com.example.damee;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView=findViewById(R.id.text_view);
        registerForContextMenu(textView);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.example_menu,menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.option_1) {
            Toast.makeText(this, "Happy cooking!!", Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(MainActivity.this,veg.class);
            startActivity(intent);

            return true;
        }
        if (item.getItemId() == R.id.option_2) {
            Toast.makeText(this, "Happy cooking!!", Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(MainActivity.this,nonveg.class);
            startActivity(intent);
            return true;
        }

            return super.onContextItemSelected(item);



    }
}